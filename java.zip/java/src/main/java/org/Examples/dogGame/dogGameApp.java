package org.Examples.dogGame;

import java.util.Scanner;

public class dogGameApp {
    public static void main(String[] args) {
        System.out.println("1 See all dogs!");
        System.out.println("2 Add new dog!");
        System.out.println("3 Remove dog ");
        System.out.println("4 Edit dog ");
        System.out.println("5 Exit!");

        while (true) {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Enter your choice: ");
            if (scanner.hasNextInt(1)) {


            }

        }





    }
}
